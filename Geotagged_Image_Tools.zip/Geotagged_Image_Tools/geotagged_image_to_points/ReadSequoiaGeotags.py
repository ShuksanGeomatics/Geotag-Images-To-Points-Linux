from libxmp import XMPFiles, consts
#from libxmp.utils import file_to_dict

in_file = '/home/gerry/Drone/20220810PointRobertsKelpMultispectralFlight/0001/IMG_220810_174222_0332_GRE.TIF'
#xmp = file_to_dict(in_file)
#print(xmp)
#for i in xmp:
    #print(i)

xmpfile = XMPFiles(file_path = in_file, open_forupdate=True )
xmp = xmpfile.get_xmp()
tags = {}
for i in xmp:
    print(xmp)
    #print(i[1]+ '  '+ i[2])
    #if i[0] =='Camera:Yaw':
        #yaw = i[1]
    #if i[0] =='Camera:Pitch':
        #pitch = i[1]
    #if i[0] =='Camera:Roll':
        #roll = i[1]
    #if i[0] =='exif:GPSLatitude':
        #latitude = i[1]
    #if i[0] =='exif:GPSLongitude':
       #longitude = i[1]  
    #if i[0] =='exif:GPSAltitude':
        #altitude = i[1]        
       

print('wait')














#class SequoiaGeotags:
    #def __init__(self,name):
        #self.name=name
        ##xmpfile = XMPFiles(file_path = inFile, open_forupdate=True )
        #xmpfile = XMPFiles(file_path = self.name, open_forupdate=True )
        #xmp = xmpfile.get_xmp()    
        #tags = {}
        #self.xmp = xmp
        #for i in xmp:
            #if i[1] == 'drone-dji:RelativeAltitude':
                ##height above take-off...
                #self.above_takeoff_alt = float(i[2])
                
            #elif i[1] == 'drone-dji:AbsoluteAltitude':
                #self.gps_altitude = float(i[2])            
                
            #elif i[1] == 'drone-dji:GimbalYawDegree':
                ##This is also the azimuth of the drone at image capture...the top of the image
                #self.gimbal_yaw = float(i[2])
                
            #elif i[1] == 'drone-dji:GimbalPitchDegree':
                ##where pitch -90 from dji is strait down so add 90 for the P3P camera
                #self.gimbal_pitch = float(i[2])+90
                
            #elif i[1] == 'drone-dji:GimbalRollDegree':
                #self.gimbal_roll= float(i[2])
                
            #elif i[1] == 'drone-dji:FlightYawDegree':
                ##This is also the azimuth of the drone at image capture...the top of the image
                #self.flight_yaw = float(i[2])
                
            #elif i[1] == 'drone-dji:FlightPitchDegree':
                ##where pitch -90 from dji is strait down so add 90 for the P3P camera
                #self.flight_pitch = float(i[2])+90
                
            #elif i[1] == 'drone-dji:FlightRollDegree':                
                #self.flight_roll= float(i[2])
                

            #elif i[1] == 'exif:PixelXDimension':
                #self.image_width = int(i[2])
                
            #elif i[1] == 'exif:PixelYDimension':
                #self.image_height = int(i[2])
               
            #elif i[1] == 'exif:FocalLength':
                #f = i[2]
                #f = f.split('/')
                #f = float(f[0]) / float(f[1])
                #self.focal_length = f
                #del f
 
            #else:
                ##if you encounter a non-needed tag pass...
                #pass
       
    

 
       

#####################################################################################################

#try:
    #def main(inFile):
        #print ("Read Geo-Tagged Photo")
        #myfile = DJIXMP(inFile)
        #print ("Above take-off elevation: ", myfile.above_takeoff_alt)
        #print ("GPS altitude:", myfile.gps_altitude)
        
        #print ("Gimbal yaw:", myfile.gimbal_yaw)
        #print ("Gimbal pitch:", myfile.gimbal_pitch)
        #print ("Gimbal roll:", myfile.gimbal_roll)
        
        #print ("Flight yaw:", myfile.flight_yaw)
        #print ("Flight pitch:", myfile.flight_pitch)
        #print ("Flight roll:", myfile.flight_roll)
        
        #print ("Image width:", myfile.image_width)
        #print ("Image height:", myfile.image_height)
        #print ("Focal length:", myfile.focal_length)
               
        #print ('Print all tags:', myfile.xmp)
        #print ("done")
#except:
    #tb = sys.exc_info()[2]
    #tbinfo = traceback.format_tb(tb)[0]
    #print ("PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1]))
  


#if __name__ == "__main__":
    
    #inFile ="/home/gerry/Georeferencetest/test_images/P4Pimages/DJI_0001.JPG"
    #main( inFile )


#class iOSEXIF:
    #def __init__(self,name):
        #self.name=name
        ##xmpfile = XMPFiles(file_path = inFile, open_forupdate=True )
        #xmpfile = XMPFiles(file_path = self.name, open_forupdate=True )
        #xmp = xmpfile.get_xmp()    
        #tags = {}
        #self.xmp = xmp
        #for i in xmp:
            #if i[1] == 'drone-dji:RelativeAltitude':
                ##height above take-off...
                #self.above_takeoff_alt = float(i[2])
                
            #elif i[1] == 'drone-dji:AbsoluteAltitude':
                #self.gps_altitude = float(i[2])            
                
            #elif i[1] == 'drone-dji:GimbalYawDegree':
                ##This is also the azimuth of the drone at image capture...the top of the image
                #self.gimbal_yaw = float(i[2])
                
            #elif i[1] == 'drone-dji:GimbalPitchDegree':
                ##where pitch -90 from dji is strait down so add 90 for the P3P camera
                #self.gimbal_pitch = float(i[2])+90
                
            #elif i[1] == 'drone-dji:GimbalRollDegree':
                #self.gimbal_roll= float(i[2])
                
            #elif i[1] == 'drone-dji:FlightYawDegree':
                ##This is also the azimuth of the drone at image capture...the top of the image
                #self.flight_yaw = float(i[2])
                
            #elif i[1] == 'drone-dji:FlightPitchDegree':
                ##where pitch -90 from dji is strait down so add 90 for the P3P camera
                #self.flight_pitch = float(i[2])+90
                
            #elif i[1] == 'drone-dji:FlightRollDegree':                
                #self.flight_roll= float(i[2])
                

            #elif i[1] == 'exif:PixelXDimension':
                #self.image_width = int(i[2])
                
            #elif i[1] == 'exif:PixelYDimension':
                #self.image_height = int(i[2])
               
            #elif i[1] == 'exif:FocalLength':
                #f = i[2]
                #f = f.split('/')
                #f = float(f[0]) / float(f[1])
                #self.focal_length = f
                #del f
 
            #else:
                ##if you encounter a non-needed tag pass...
                #pass
       







#inFile = DJIXMP("/home/gerry/Georeferencetest/test_images/P4Pimages/DJI_0001.JPG" )   
#print(inFile.gimbal_yaw)